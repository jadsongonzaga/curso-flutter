
import 'package:flutter/material.dart';
import 'app_widget.dart';

main() {
  runApp(AppWidget(title: "Titulo"));
}

  /*
  @override
  Widget build(BuildContext context) {
    return Container(
    child: Center(
      child: Text(
        title,
        textDirection:  TextDirection.ltr,
        style: TextStyle(color: Colors.white, fontSize: 50.0),
        ),
    ));
  }
  
   */
